/*
  ==============================================================================

    DJAudioPlayer,h.cpp
    Created: 29 Jan 2022 2:14:35pm
    Author:  Tey Hao Teck

  ==============================================================================
*/

#include "DJAudioPlayer.h"

//Constructor for the AudioPlayer and the initialization list
DJAudioPlayer::DJAudioPlayer(juce::AudioFormatManager& _formatManager)
    : formatManager(_formatManager)
{

}

DJAudioPlayer::~DJAudioPlayer()
{

}

//==============================================================================
void DJAudioPlayer::prepareToPlay(int samplesPerBlockExpected, double sampleRate)
{
    transportSource.prepareToPlay(samplesPerBlockExpected, sampleRate);
    resampleSource.prepareToPlay(samplesPerBlockExpected, sampleRate);
}

//Getting the next audio block to play from the buffer
void DJAudioPlayer::getNextAudioBlock(const juce::AudioSourceChannelInfo& bufferToFill)
{
    resampleSource.getNextAudioBlock(bufferToFill);
}

//Releasing resources
void DJAudioPlayer::releaseResources()
{
    transportSource.releaseResources();
    resampleSource.releaseResources();
}

//==============================================================================

//Loading the file into the transportSource
void DJAudioPlayer::loadURL(juce::URL audioURL)
{
    juce::AudioFormatReader* reader = formatManager.createReaderFor(audioURL.createInputStream(false));

    if (reader != nullptr)
    {
        std::unique_ptr<juce::AudioFormatReaderSource> newSource
        (new juce::AudioFormatReaderSource(reader, true));

        transportSource.setSource(newSource.get(), 0, nullptr, reader->sampleRate);
        readerSource.reset(newSource.release());
    }
    else
    {
        DBG("Something went wrong in the file");
    }
}

//Setting the gain of the transportSource using the function from the AudioTransportSource class
void DJAudioPlayer::setGain(double gain)
{
    if (gain < 0 || gain > 1.0)
    {
        DBG("DJAudioPlayer::setGain gain should be between 0 and 1");
    }
    else
    {
        transportSource.setGain(gain);
    }
}

//Setting the speed using the function from the ResamplingAudioSource class
void DJAudioPlayer::setSpeed(double ratio)
{
    if (ratio < 0 || ratio > 100.0)
    {
        DBG("DJAudioPlayer::setSpeed ratio should be between 0 and 100");
    }
    else
    {
        resampleSource.setResamplingRatio(ratio);
    }
}

//Setting the position of the transportSource using the function from the AudioTransportSource class
void DJAudioPlayer::setPosition(double posInSecs)
{
    transportSource.setPosition(posInSecs);
}

//Setting the position of the transportSource relative to range of the slider being 0 and 1
void DJAudioPlayer::setPositionRelative(double pos)
{
    if (pos < 0 || pos > 1.0)
    {
        DBG("DJAudioPlayer::setPositionRelative pos should be between 0 and 1");
    }
    else
    {
        double posInSecs = transportSource.getLengthInSeconds() * pos;
        setPosition(posInSecs);
    }
}

//Starting of playback
void DJAudioPlayer::start()
{
    transportSource.start();
}

//Stopping of the playback 
void DJAudioPlayer::stop()
{
    transportSource.stop();
}

//move the audio file behind
void DJAudioPlayer::rewind()
{
    //make sure audio position is not negative  
    if (transportSource.getCurrentPosition() - 1 > 0)
    {
        //reduce position of the audio 1.5 seconds
        transportSource.setPosition(transportSource.getCurrentPosition() - 1.5);
    }
}

//move the audio file forward
void DJAudioPlayer::forward()
{
    //get the length of the track
    double last_pos{ transportSource.getLengthInSeconds() };

    //make sure position of the audio does not exceed the length of the audio
    if (transportSource.getCurrentPosition() + 0.5 != last_pos || transportSource.getCurrentPosition() + 0.5 > last_pos)
    {
        //move forward position of the audio 1.5 seconds 
        transportSource.setPosition(transportSource.getCurrentPosition() + 1.5);
    }
}

//The below 4 functions are pure virtual functions that need to be implemented
//  since we inherit from the PositionableAudioSource class
void DJAudioPlayer::setNextReadPosition(juce::int64 newPosition)
{

}

juce::int64 DJAudioPlayer::getNextReadPosition() const
{
    return readerSource->getNextReadPosition();
}

juce::int64 DJAudioPlayer::getTotalLength() const
{
    return readerSource->getTotalLength();
}

//Returning true if it is looping, or false if it is not
bool DJAudioPlayer::isLooping() const
{
    return false;
}

//function to loop the audio file
void DJAudioPlayer::setLoop()
{
    if (readerSource != nullptr)
    {
        //looping audio file automatically after ending
        readerSource->setLooping(true);
    }
}

//function to unloop the audio file
void DJAudioPlayer::unsetLoop()
{
    if (readerSource != nullptr)
    {
        //unloop the audio file, not replaying audio file
        readerSource->setLooping(false);
    }
}

//get the relative position of the playhead returned as a double
double DJAudioPlayer::getPositionRelative()
{
    return transportSource.getCurrentPosition() / transportSource.getLengthInSeconds();
}

//A function that returns the total time of the track in minutes and seconds as a String
juce::String DJAudioPlayer::getSongLength()
{
    double length_minutes{ transportSource.getLengthInSeconds() / 60 };

    //Variables needed to seperate the integer and fractional value of the calculated minutes
    //from the return value in seconds of the function getLengthInSeconds
    double fractional_part, integer_part;
    fractional_part = modf(length_minutes, &integer_part);

    //two variables that hold the calculated minutes and seconds
    std::string minutes{ std::to_string((int)integer_part) };
    std::string seconds{ std::to_string((int)round(fractional_part * 60)) };

    juce::String final_string{ minutes + " min : " + seconds + " sec" };

    return final_string;
}
