/*
  ==============================================================================

    DJAudioPlayer.h
    Created: 29 Jan 2022 2:15:06pm
    Author:  Tey Hao Teck

  ==============================================================================
*/

#pragma once
#include <JuceHeader.h>

class DJAudioPlayer : public juce::AudioSource,
    public juce::PositionableAudioSource
{
public:

    DJAudioPlayer(juce::AudioFormatManager& _formatManager);
    ~DJAudioPlayer();

    //==============================================================================
    //The 3 functions that need to be implemented since we inherit from AudioSource
    //As they are pure virtual functions
    void prepareToPlay(int samplesPerBlockExpected, double sampleRate) override;
    void getNextAudioBlock(const juce::AudioSourceChannelInfo& bufferToFill) override;
    void releaseResources() override;

    //==============================================================================

    //All the public functions needed to operate on the AudioTransportSource

    //Loading the file into the transportSource object 
    void loadURL(juce::URL audioURL);
    //Setting the gain 
    void setGain(double gain);
    //Setting the speed at which the track is played
    void setSpeed(double ratio);
    //Setting the position on the transportSource in seconds
    void setPosition(double posInSecs);
    //Setting the position in seconds relative to between 0 and 1
    void setPositionRelative(double pos);

    //A function that return the total time of the track in minutes and seconds
    juce::String getSongLength();

    //Functions to be able to start, stop, move backwards, and move forwards
    //on the transportSource
    void start();
    void stop();
    void rewind();
    void forward();

    //Implementing the below 4 function since we inherit from PositionableAudioSource class to implement the looping function
    void setNextReadPosition(juce::int64 newPosition) override;
    juce::int64 getNextReadPosition() const override;
    juce::int64 getTotalLength() const override;
    bool isLooping() const override;

    //Functions to set the playback to loop or not to loop
    void setLoop();
    void unsetLoop();

    //get the relative position of the playhead
    double getPositionRelative();

    //The AudioTransportSource object used to play a file
    juce::AudioTransportSource transportSource;

private:

    //To be able to read audio from file
    juce::AudioFormatManager& formatManager;

    //smart pointer    
    std::unique_ptr<juce::AudioFormatReaderSource> readerSource;

    juce::ResamplingAudioSource resampleSource{ &transportSource, false, 2 };
};