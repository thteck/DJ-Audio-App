/*
  ==============================================================================

    DeckGUI.cpp
    Created: 29 Jan 2022 5:33:02pm
    Author:  Tey Hao Teck

  ==============================================================================
*/

#include <JuceHeader.h>
#include "DeckGUI.h"

//==============================================================================
//DeckGUI constructor initialized with all the variables
DeckGUI::DeckGUI(DJAudioPlayer* _player,
    PlaylistComponent* _trackList,
    TrackTitle* _title,
    WaveformDisplay* _display)
    : player(_player),
    trackList(_trackList),
    title(_title),
    w_display(_display)
{
    //Function to make the buttons/sliders visible in the constructor of the DeckGUI
    addAndMakeVisible(playButton);
    addAndMakeVisible(resetButton);
    addAndMakeVisible(loadFile);
    addAndMakeVisible(SaveToPlaylist);
    addAndMakeVisible(loop);
    addAndMakeVisible(rewind);
    addAndMakeVisible(fforward);

    //Setting the below buttons to be triggered when they are pressed down
    //as the default setting is that they are triggered when the mouse button is released
    resetButton.setTriggeredOnMouseDown(true);
    playButton.setTriggeredOnMouseDown(true);
    rewind.setTriggeredOnMouseDown(true);
    fforward.setTriggeredOnMouseDown(true);

    //Making visible the 3 sliders
    addAndMakeVisible(volume);
    addAndMakeVisible(speed);
    addAndMakeVisible(position);

    //Register the buttons/slider to the event listener
    playButton.addListener(this);
    resetButton.addListener(this);
    loadFile.addListener(this);
    SaveToPlaylist.addListener(this);
    rewind.addListener(this);
    fforward.addListener(this);

    volume.addListener(this);
    speed.addListener(this);
    position.addListener(this);
    loop.addListener(this);

    //set the range for the sliders
    volume.setRange(0.0, 1.0);
    speed.setRange(0.0, 10);
    position.setRange(0.0, 1.0);

    //The volume and speed sliders are changed to a rotary style slider and set the textbox beside the slider
    volume.setSliderStyle(juce::Slider::Rotary);
    volume.setTextBoxStyle(juce::Slider::TextEntryBoxPosition::TextBoxLeft , false, 50, 20);
    volume.setNumDecimalPlacesToDisplay(3);

    speed.setSliderStyle(juce::Slider::Rotary);
    speed.setTextBoxStyle(juce::Slider::TextEntryBoxPosition::TextBoxLeft, false, 50, 20);
    speed.setNumDecimalPlacesToDisplay(3);
}

DeckGUI::~DeckGUI()
{
    stopTimer();
}

void DeckGUI::paint(juce::Graphics& g)
{
    g.fillAll(juce::Colours::black);

    g.setColour(juce::Colours::lightgrey);
    g.drawRect(getLocalBounds(), 1);   // draw an outline around the component

    g.setFont(14.0F);

    // Label each slider with its corresponding function
    g.drawSingleLineText("Volume", volume.getX(), volume.getY() + volume.getHeight()/3, juce::Justification::centredLeft);
    g.drawSingleLineText("Speed", speed.getX(), speed.getY()+speed.getHeight()/3, juce::Justification::centredLeft);
    g.drawSingleLineText("Position", position.getX(), position.getY(), juce::Justification::centredLeft);

    //A call to the buttons and sliders painting functions
    buttonsRepainting();
    slidersRepainting();
}

void DeckGUI::resized()
{
    // This method is where you should set the bounds of any child
    // components that your component contains..

    double rowH = 50;
    double button_width = getWidth() / 5;

    //All the elements that make up a DeckGUI component are positioned 
    rewind.setBounds(0, 0, button_width, rowH);
    playButton.setBounds(button_width, 0, button_width*2, rowH);
    resetButton.setBounds(button_width * 3, 0, button_width, rowH);
    fforward.setBounds(button_width * 4, 0, button_width, rowH);

    loadFile.setBounds(0, rowH, getWidth() / 2, rowH);
    SaveToPlaylist.setBounds(getWidth() / 2, rowH, getWidth() / 2, rowH);

    double slider_width = getWidth() / 2.5;

    volume.setBounds(0, rowH * 2, slider_width, rowH * 2.5);
    speed.setBounds(slider_width, rowH * 2, slider_width, rowH * 2.5);
    loop.setBounds(slider_width * 2, rowH * 2.5, button_width, rowH);

    position.setBounds(5, rowH * 4, getWidth() - 5, rowH);
}

//A function that is implemented since we inherit from Button Listener class
//  and the below function is a pure virtual function
void DeckGUI::buttonClicked(juce::Button* button)
{
    //If the play / pause button is clicked the following happens
    if (button == &playButton)
    {
        //A check is made to see whether the player is already playing a track
        //if so, the player just stops playing
        if (player->transportSource.isPlaying())
        {
            DBG("Track paused");
            player->stop();
        }
        else
        {
            //if the player is not playing
            DBG("Track started/resumed");
            //This is a check to see whether the track is being played 
            //for the first time or not.
            //If yes, the following settings are done to the player and sliders
            if (started == false)
            {
                volume.setValue(0.25, juce::dontSendNotification);
                player->setGain(volume.getValue());
                speed.setValue(1.00, juce::dontSendNotification);
                player->setSpeed(speed.getValue());
            }
            //player starts playing
            player->start();
            //the started bool variable is set to true
            started = true;
            //If the player is playing the timer is started
            if (player->transportSource.isPlaying())
            {
                startTimer(200);
            }
        }
    }

    //reset button has been clicked,set position of audio file to 0
    if (button == &resetButton)
    {
        player->setPosition(0);
        player->stop();
        started = false;
    }

    //if load button has been clicked, it will call the file chooser to select audio file
    //the selected audio file is then loaded into the player
    //load the title and length of the selected audio file as well
    if (button == &loadFile)
    {
        //Open a file chooser from the device
        juce::FileChooser chooser{ "Please select a file..." };
        //An audio file has been selected correctly
        if (chooser.browseForFileToOpen())
        {
            //store the selected audio file
            fileLoaded = chooser.getResult();
            //load the selected audio file into the DJ player
            player->loadURL(juce::URL{ fileLoaded });
            //load the waveform of selected audio filea
            w_display->loadURL(juce::URL{ fileLoaded });
            //load the file name and length of the selected audio file
            title->setTitle(fileLoaded.getFileNameWithoutExtension().toUpperCase(), player->getSongLength());
            //When loop button has been toggled
            if (loop.getToggleState() == true)
            {
                //replay the audio file
                player->setLoop();
            }
        }
    }

    //Whenever the SaveToPlaylist button is pressed, the loaded track gets added to the playlist
    //  by the addAudioFile function passing the file
    if (button == &SaveToPlaylist)
    {
        trackList->addAudioFile(&fileLoaded);
    }

    //If the toggle button loop is set to on, the player is set to loop
    //and vice versa if the toggle state is false, the player is set to not loop
    if (button == &loop)
    {
        if (loop.getToggleState() == true)
        {
            player->setLoop();
        }
        else
        {
            player->unsetLoop();
        }
    }
}

//Implement a slider listener
void DeckGUI::sliderValueChanged(juce::Slider* slider)
{
    //Wheneve the gain slider value changes, the player's gain is changed according to the
    //slider's value
    if (slider == &volume)
    {
        player->setGain(slider->getValue());
    }

    //Wheneve the speed slider value changes, the player's speed is changed according to the
    //slider's value
    if (slider == &speed)
    {
        player->setSpeed(slider->getValue());
    }

    //Wheneve the position slider value changes the player's position along the track is changed according to the
    //slider's value. Also, the position of the playhead in the waveform display changes according to the slider's value
    if (slider == &position)
    {
        player->setPositionRelative(slider->getValue());
        w_display->setPositionRelative(player->getPositionRelative());
    }
}

//A function that gets called instead the timerCallBack function
void DeckGUI::buttonTimerCallback()
{
    //If the rewind button is down the player is playing, rewind button is on
    //and the player rewind function gets called
    if (rewind.isDown())
    {
        if (player->transportSource.isPlaying())
        {
            rewind.setToggleState(true, false);
            player->rewind();
        }
    }
    //else the toggle state is set to false
    else
    {
        rewind.setToggleState(false, false);
    }

    //As above the same checks are done,
    //if the conditions are true, the fforward toggle state is set to true and 
    //the player forward function gets called
    if (fforward.isDown())
    {
        if (player->transportSource.isPlaying())
        {
            fforward.setToggleState(true, false);
            player->forward();
        }
    }
    //else, the toggle state is set to false
    else
    {
        fforward.setToggleState(false, false);
    }
}

//Implementing this function since we inherit from the timer class
void DeckGUI::timerCallback()
{
    //The function gets called
    buttonTimerCallback();

    //Moving the position slider according to the new position of the transportSource 
    //normalized between 0 and 1
    position.setValue(player->getPositionRelative(), juce::NotificationType::dontSendNotification);
    //The playhead position is updated according to the player's relative position
    w_display->setPositionRelative(player->getPositionRelative());
}

void DeckGUI::buttonsRepainting()
{
    //The below if conditions checks whether the mouse is over the respective button or not
    //If the mouse is over the button, it gets painted a grey colour,
    //  if not, it is painted a black colour
    if (playButton.isOver())
    {
        playButton.setColour(juce::TextButton::buttonColourId, juce::Colours::grey);
    }
    else
    {
        playButton.setColour(juce::TextButton::buttonColourId, juce::Colours::black);
    }

    if (resetButton.isOver())
    {
        resetButton.setColour(juce::TextButton::buttonColourId, juce::Colours::grey);
    }
    else
    {
        resetButton.setColour(juce::TextButton::buttonColourId, juce::Colours::black);
    }

    if (loadFile.isOver())
    {
        loadFile.setColour(juce::TextButton::buttonColourId, juce::Colours::grey);
    }
    else
    {
        loadFile.setColour(juce::TextButton::buttonColourId, juce::Colours::black);
    }

    if (SaveToPlaylist.isOver())
    {
        SaveToPlaylist.setColour(juce::TextButton::buttonColourId, juce::Colours::grey);
    }
    else
    {
        SaveToPlaylist.setColour(juce::TextButton::buttonColourId, juce::Colours::black);
    }

    if (rewind.isOver())
    {
        rewind.setColour(juce::TextButton::buttonColourId, juce::Colours::grey);
    }
    else
    {
        rewind.setColour(juce::TextButton::buttonColourId, juce::Colours::black);
    }

    if (fforward.isOver())
    {
        fforward.setColour(juce::TextButton::buttonColourId, juce::Colours::grey);
    }
    else
    {
        fforward.setColour(juce::TextButton::buttonColourId, juce::Colours::black);
    }
}

//The function that takes care of the colours to be used by the sliders
void DeckGUI::slidersRepainting()
{
    volume.setColour(juce::Slider::thumbColourId, juce::Colours::white);
    speed.setColour(juce::Slider::thumbColourId, juce::Colours::white);
    position.setColour(juce::Slider::thumbColourId, juce::Colours::white);

    volume.setColour(juce::Slider::rotarySliderFillColourId, juce::Colours::grey);
    speed.setColour(juce::Slider::rotarySliderFillColourId, juce::Colours::grey);
    position.setColour(juce::Slider::trackColourId, juce::Colours::grey);
}
