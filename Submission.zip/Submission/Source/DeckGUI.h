/*
  ==============================================================================

    DeckGUI.h
    Created: 29 Jan 2022 5:33:02pm
    Author:  Tey Hao Teck

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include "DJAudioPlayer.h"
#include "PlaylistComponent.h"
#include "TrackTitle.h"
#include "WaveformDisplay.h"

//==============================================================================
/*A class that inherits from Component, Button Listener, Slider Listener and timer classes
*/
class DeckGUI : public juce::Component,
    public juce::Button::Listener,
    public juce::Slider::Listener,
    public juce::Timer
{
public:
    //Constructor for a Deck GUI that takes a player, a playlist component, 
    //a track title and a waveform display as parameters
    DeckGUI(DJAudioPlayer* player,
        PlaylistComponent* _trackList,
        TrackTitle* _title,
        WaveformDisplay* _display);

    ~DeckGUI() override;

    void paint(juce::Graphics&) override;
    void resized() override;

    //Needs to be implemented since we inherit from Button::Listener class
    void buttonClicked(juce::Button* button) override;

    //Implement a slider listener
    void sliderValueChanged(juce::Slider* slider) override;

    //Implementing this function since we inherit from the timer class
    void timerCallback() override;

    //A function that takes care of the painting and graphical representation of the buttons
    void buttonsRepainting();

    //A function that takes care of the painting and graphical representation of the sliders
    void slidersRepainting();

private:

    //A function that perform operations on the buttons in the timercallback function
    void buttonTimerCallback();

    //Set of buttons 
    juce::TextButton playButton{ " Play / Pause " };
    juce::TextButton resetButton{ " Reset " };
    juce::TextButton loadFile{ " LOAD " };
    juce::TextButton SaveToPlaylist{ " Save to Playlist " };
    juce::TextButton rewind{ "<<" };
    juce::TextButton fforward{ ">>" };
    juce::ToggleButton loop{ "Loop" };

    //3 sliders for the volume, speed and position
    juce::Slider volume;
    juce::Slider speed;
    juce::Slider position;

    //A pointer to a tracklist - playlist component
    PlaylistComponent* trackList;

    //A pointer to a player that goes with the deck 
    DJAudioPlayer* player;

    //A pointer to track title component
    TrackTitle* title;

    //A file variable to store the loaded file
    juce::File fileLoaded;

    //A pointer to a waveform display
    WaveformDisplay* w_display;

    //bool variables to indicate if a track has started or not,
    //used by the play / pause button
    bool started{ false };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(DeckGUI)
};
