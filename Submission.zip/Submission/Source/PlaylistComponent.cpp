/*
  ==============================================================================

    PlaylistComponent.cpp
    Created: 12 Feb 2022 2:38:31pm
    Author:  Tey Hao Teck

  ==============================================================================
*/

#include <JuceHeader.h>
#include "PlaylistComponent.h"
#include <iostream>

//==============================================================================
//Playlist Component constructor with all the variables initialized
// -- Audio players that are used by the playlist component to choose where to load the track
//         when the user choose to load a track from the playlist
// -- Tmp audio player is used to calculate the track length of each track while loading it from file
// -- Waveform displays are used to choose where to display the title
// -- TrackTitles objects are used to choose which display is used when a track is loaded
PlaylistComponent::PlaylistComponent(DJAudioPlayer* _player1,
    DJAudioPlayer* _player2,
    DJAudioPlayer* _tmp,
    WaveformDisplay* _display1,
    WaveformDisplay* _display2,
    TrackTitle* _title_d1,
    TrackTitle* _title_d2)
    : player1(_player1),
    player2(_player2),
    tmp_player(_tmp),
    w_display1(_display1),
    w_display2(_display2),
    titled1(_title_d1),
    titled2(_title_d2)
{
    //Setting up the Headers and column titles of the playlist TableListBox
    playlist.getHeader().addColumn("Track Title", 1,200);
    playlist.getHeader().addColumn("Location", 2, 200);
    playlist.getHeader().addColumn("Length", 3, 200);
    playlist.getHeader().addColumn("Deck 1", 4, 100);
    playlist.getHeader().addColumn("Deck 2", 5, 100);
    //The playlist is enabled to accept multiple selection of rows instead of 1 at a time
    playlist.setMultipleSelectionEnabled(true);

    //Making visible the playlist TableListBox, SearchField and inputText Labels
    addAndMakeVisible(playlist);
    addAndMakeVisible(searchField);
    addAndMakeVisible(inputText);

    //Setting this playlist component as a model to the TableListBox playlist since
    //the playlist component is a TableListBoxModel
    playlist.setModel(this);

    //The directories of each track are read from file to be displayed by the playlist
    loadDirectories();
}

PlaylistComponent::~PlaylistComponent()
{
    //When this component is destructed when closing the app
    //the directories of all the tracks that are found in the playlist get written to file 
    //using the savePlaylistToFile function
    savePlaylistToFile();
}

void PlaylistComponent::paint(juce::Graphics& g)
{
    g.fillAll(juce::Colours::black);
    g.setColour(juce::Colours::darkgrey);
    g.drawRect(getLocalBounds(), 1);   // draw an outline around the component

    //Setting the inputText label to be editable so the user can enter text to search music
    inputText.setEditable(true);
    //Setting the colour of the text
    inputText.setColour(juce::Label::textColourId, juce::Colours::white);
    //When user presses the return button the searchTrack function is called passing the text entered by the user
    inputText.onTextChange = [this] {searchTrack(inputText.getText()); };

    //Below are the settings for the searchField label
    searchField.setText("Search for Music: ", juce::NotificationType::dontSendNotification);
    searchField.setFont(juce::Font(16.0f, juce::Font::bold));
    //Attaching the searchField label to go with the inputText
    searchField.attachToComponent(&inputText, true);
    searchField.setColour(juce::Label::textColourId, juce::Colours::white);
    searchField.setJustificationType(juce::Justification::right);
}

void PlaylistComponent::resized()
{
    // This method is where you should set the bounds of any child
    // components that your component contains..
    inputText.setBounds(125, 0, getWidth() - 125, 25);
    playlist.setBounds(0, 25, getWidth(), getHeight() - 50);

    int column_width = getWidth() / 8;
    playlist.getHeader().setColumnWidth(1, column_width*2);
    playlist.getHeader().setColumnWidth(2, column_width*2);
    playlist.getHeader().setColumnWidth(3, column_width*2);
    playlist.getHeader().setColumnWidth(4, column_width);
    playlist.getHeader().setColumnWidth(5, column_width);
}

//Implemented because it is a pure virtual function of the TableListBoxModel abstract class
int PlaylistComponent::getNumRows()
{
    return tracksFile.size();
}

void PlaylistComponent::paintRowBackground(juce::Graphics& g,
    int rowNumber,
    int width,
    int height,
    bool rowIsSelected)
{

    if (rowNumber < getNumRows())
    {
        //When a row is selected it changes colour to orange, when it is not, its colour is lightseagreen
        if (rowIsSelected == true)
        {
            g.fillAll(juce::Colours::darkgrey);
        }
        else
        {
            g.fillAll(juce::Colours::black);
        }
    }
}

void PlaylistComponent::paintCell(juce::Graphics& g,
    int rowNumber,
    int columnId,
    int width,
    int height,
    bool rowIsSelected)
{
    if (rowNumber < getNumRows())
    {
        //The next file in the tracksFile vector is loaded into the tmp player so that the songlength
        // is extracted
        tmp_player->loadURL(juce::URL(tracksFile[rowNumber]));
        g.setColour(juce::Colours::white);

        //At column 1 the file name / track title is displayed
        if (columnId == 1)
        {
            g.drawText(tracksFile[rowNumber].getFileNameWithoutExtension(),
                2,
                0,
                width - 4,
                height,
                juce::Justification::horizontallyCentred,
                true);
        }

        //At column 2 the location of the file is displayed
        if (columnId == 2)
        {
            g.drawText(tracksFile[rowNumber].getFullPathName(),
                2,
                0,
                width - 4,
                height,
                juce::Justification::horizontallyCentred,
                true);
        }

        //At column 3 the song length in minutes and seconds is displayed
        if (columnId == 3)
        {
            g.drawText(tmp_player->getSongLength(),
                2,
                0,
                width - 4,
                height,
                juce::Justification::horizontallyCentred,
                true);
        }
    }
}

juce::Component* PlaylistComponent::refreshComponentForCell(int rowNumber,
    int columnId,
    bool isRowSelected,
    juce::Component* existingComponentToUpdate)
{
    //We re attaching a text button to eachcell in column 4 that enables 
    //the user to load a track into a player 
    if (columnId == 4)
    {
        if (existingComponentToUpdate == nullptr)
        {
            juce::TextButton* loadbutton = new juce::TextButton{ "Load" };
            juce::String id{ std::to_string(rowNumber) };
            loadbutton->setComponentID(id);
            loadbutton->setName("Deck_one");
            loadbutton->setColour(juce::TextButton::buttonColourId, juce::Colours::black);
            loadbutton->addListener(this);
            existingComponentToUpdate = loadbutton;
        }
    }

    if (columnId == 5)
    {
        if (existingComponentToUpdate == nullptr)
        {
            juce::TextButton* loadbutton = new juce::TextButton{ "Load" };
            juce::String id{ std::to_string(rowNumber) };
            loadbutton->setComponentID(id);
            loadbutton->setName("Deck_two");
            loadbutton->setColour(juce::TextButton::buttonColourId, juce::Colours::black);
            loadbutton->addListener(this);
            existingComponentToUpdate = loadbutton;
        }
    }

    return existingComponentToUpdate;
}

//load tracks button is pressed and call this function
void PlaylistComponent::buttonClicked(juce::Button* button)
{
    //The component id set in the refreshComponentForCell function is extracted from each button
    int id = std::stoi(button->getComponentID().toStdString());
    if(button->getName() == "Deck_one")
    {
        //load the track into player 1
        player1->loadURL(juce::URL{ tracksFile[id] });
        titled1->setTitle(tracksFile[id].getFileNameWithoutExtension().toUpperCase(), player1->getSongLength());
        w_display1->loadURL(juce::URL{ tracksFile[id] });
    }
    else if (button->getName() == "Deck_two")
    {
        //load the track into player 2
        player2->loadURL(juce::URL{ tracksFile[id] });
        titled2->setTitle(tracksFile[id].getFileNameWithoutExtension().toUpperCase(), player2->getSongLength());
        w_display2->loadURL(juce::URL{ tracksFile[id] });
    }
}
//function to add file into track list
void PlaylistComponent::addAudioFile(juce::File* audioFile)
{
    //bool variable used as a signal whether the file already exists or not
    bool alreadyExists{ false };

    for (juce::File& file : tracksFile)
    {
        //check if file exists in the track list already
        if (file.getFileName().equalsIgnoreCase(audioFile->getFileName()))
        {
            alreadyExists = true;
            break;
        }
    }

    //new file does not exists, add it into the track list
    if (alreadyExists == false && audioFile->getFullPathName() != "")
    {
        tracksFile.push_back(*audioFile);
        playlist.updateContent();
        playlist.repaint();
    }
}

//A function that reads the playlist and saves the URLs to file
void PlaylistComponent::savePlaylistToFile()
{
    //A file output stream used to write to file
    juce::FileOutputStream stream{ playlistFile };

    //If the file output stream opened ok, the stream position is set at the beginning of the file
    //For each file in tracksFile vector the directory string is written to file added a carriage return 
    //for ease of reading when the file is read back
    if (stream.openedOk() == true)
    {
        stream.setPosition(0);

        for (auto& file : tracksFile)
        {
            juce::String directory{ file.getFullPathName() + "\n" };
            stream.writeText(directory, false, false, nullptr);
        }
        //stream is flushed to make sure that everything in the stream is written to file
        stream.flush();
    }
}

//A function to load the URLs of the files found in the playlist textfiles
void PlaylistComponent::loadDirectories()
{
    //An input stream is opened indicating the file that is used to read from
    juce::FileInputStream stream{ playlistFile };

    //if stream opened ok, a string is created for each line and a new file
    //is created from the line read and added to the tracksFile vector
    if (stream.openedOk() == true)
    {
        while (!stream.isExhausted())
        {
            juce::String str = stream.readNextLine();
            tracksFile.push_back(juce::File{ str });
        }
    }
    else
    {
        DBG("INPUT STREAM failed to open");
    }
}

//function to seach for music in playlist
void PlaylistComponent::searchTrack(juce::String text)
{
    //deselect all rows in the playlist
    playlist.deselectAllRows();

   //loop throught the playlist vector
    for (int i = 0; i < tracksFile.size(); ++i)
    {
        //check if any of the filename is equal to the input text
        if (tracksFile[i].getFileNameWithoutExtension().equalsIgnoreCase(text)
            || tracksFile[i].getFileNameWithoutExtension().containsIgnoreCase(text))
        {
            //the row is selected if condition above is met
            playlist.selectRow(i, false, false);
            playlist.updateContent();
            playlist.repaint();
        }
    }
}